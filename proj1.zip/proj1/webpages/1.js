alert('d');
var obj = {
	get_data : function()
	{
		this.xhr = new XMLHttpRequest();
		this.xhr.onreadystatechange = this.result;
		this.xhr.open("GET","http://localhost:8000/movies",true);
		this.xhr.send();
	},
	res : function()
	{
		if(this.readyState == 4 && this.status == 200)
			{
				var div = document.createElement("div");
				div.innerHTML = this.responseText;
				document.body.appendChild(div);
			}
	}
}