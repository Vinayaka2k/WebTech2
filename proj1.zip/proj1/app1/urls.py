from django.urls import path
from . import views
urlpatterns = [
	path('get_recommendations',views.getRecommendations,name="get_recommendations"),
	path('getmovies',views.getMovies,name="getmovies"),
	path('welcome',views.welcome,name="welcome"),
	path('add_movie',views.addMovie,name="add_movie"),
	path('recommend',views.recommend,name="recommend"),
	path('user_history',views.user_history,name="user_history"),
]