"""proj1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path , include
from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# Create your views here.
def home(request):
	#return render(request, 'home.html')
	#return render(request, 'home.html', {'name':'vinu'})
	df = pd.read_csv(r"C:\Users\VINU PC\Desktop\movie_dataset.csv")
	features = ['keywords','cast','genres','director']
	
	def combine_features(row):
	    return row['keywords'] +" "+row['cast']+" "+row["genres"]+" "+row["director"]
	
	for feature in features:
	    df[feature] = df[feature].fillna('')
	df["combined_features"] = df.apply(combine_features,axis=1)
	cv = CountVectorizer()
	count_matrix = cv.fit_transform(df["combined_features"])
	cosine_sim = cosine_similarity(count_matrix)
	def get_title_from_index(index):
	    return df[df.index == index]["title"].values[0]
	def get_index_from_title(title):
	    return df[df.title == title]["index"].values[0]
	movie_user_likes = "Avatar"
	movie_index = get_index_from_title(movie_user_likes)
	similar_movies =  list(enumerate(cosine_sim[movie_index]))
	sorted_similar_movies = sorted(similar_movies,key=lambda x:x[1],reverse=True)[1:]
	i=0
	#print("Top 10 similar movies to "+movie_user_likes+" are:\n")
	s = ""
	for element in sorted_similar_movies:
	    s=s+get_title_from_index(element[0])
	    s=s+"<br>"
	    i=i+1
	    if i>=5:
	        break
	return HttpResponse(s)


urlpatterns = [
	#path('', include('app1.urls')),
	path('',home,name="home"),
	path('admin/', admin.site.urls),
]
